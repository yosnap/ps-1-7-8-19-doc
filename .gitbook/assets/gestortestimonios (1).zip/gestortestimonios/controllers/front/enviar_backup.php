<?php

/**
 * Controlador Frontend para enviar testimonios
 * Archivo: controllers/front/enviar.php
 */

class GestortestimoniosEnviarModuleFrontController extends ModuleFrontController {
    public function __construct() {
        parent::__construct();
        $this->context = Context::getContext();
    }

    /**
     * Inicializar el controlador
     */
    public function init() {
        parent::init();
        error_log('[GESTOR_TESTIMONIOS_FO] Init método ejecutado');
    }

    /**
     * Procesar la petición
     */
    public function initContent() {
        parent::initContent();

        error_log('[GESTOR_TESTIMONIOS_FO] initContent() - Inicio del método');
        error_log('[GESTOR_TESTIMONIOS_FO] POST data: ' . print_r($_POST, true));
        error_log('[GESTOR_TESTIMONIOS_FO] submitTestimonio present: ' . (Tools::isSubmit('submitTestimonio') ? 'YES' : 'NO'));

        $success = false;
        $error = '';
        $message = '';

        // Procesar formulario si se envió
        if (Tools::isSubmit('submitTestimonio')) {
            error_log('[GESTOR_TESTIMONIOS_FO] Procesando formulario de testimonio...');
            $result = $this->processTestimonioForm();
            $success = $result['success'];
            $error = isset($result['error']) ? $result['error'] : '';
            $message = isset($result['message']) ? $result['message'] : '';

            error_log('[GESTOR_TESTIMONIOS_FO] Resultado del procesamiento - Success: ' . ($success ? 'TRUE' : 'FALSE') . ', Error: ' . $error . ', Message: ' . $message);
        }

        // Datos del formulario (mantener datos si hay error)
        $form_data = [
            'client_name' => Tools::getValue('client_name', ''),
            'company' => Tools::getValue('company', ''),
            'email' => Tools::getValue('email', ''),
            'testimonial_text' => Tools::getValue('testimonial_text', ''),
            'rating' => Tools::getValue('rating', '')
        ];

        // Información del cliente logueado
        $customer_info = [];
        if ($this->context->customer->isLogged()) {
            $customer_info = [
                'firstname' => $this->context->customer->firstname,
                'lastname' => $this->context->customer->lastname,
                'email' => $this->context->customer->email,
                'id' => $this->context->customer->id
            ];
        }

        // Configuración de rating
        $min_rating = Configuration::get('GESTOR_TESTIMONIOS_MIN_RATING');
        $max_rating = Configuration::get('GESTOR_TESTIMONIOS_MAX_RATING');

        // Asignar variables a Smarty
        $this->context->smarty->assign([
            'form_data' => $form_data,
            'customer_info' => $customer_info,
            'success' => $success ? $message : false,
            'error' => $error,
            'min_rating' => $min_rating,
            'max_rating' => $max_rating,
            'csrf_token' => $this->module->generateCSRFToken(),
            'testimonios_link' => $this->context->link->getModuleLink(
                'gestortestimonios',
                'testimonios'
            ),
            'module_dir' => $this->module->getPathUri()
        ]);

        // Establecer el template
        $this->setTemplate('module:gestortestimonios/views/templates/front/enviar.tpl');
    }

    /**
     * Procesar formulario de testimonio
     */
    private function processTestimonioForm() {
        error_log('[GESTOR_TESTIMONIOS_FO] processTestimonioForm() - Inicio');

        // Validar token CSRF
        $csrf_token = Tools::getValue('csrf_token');
        error_log('[GESTOR_TESTIMONIOS_FO] CSRF Token recibido: ' . $csrf_token);

        if (!$this->module->validateCSRFToken($csrf_token)) {
            error_log('[GESTOR_TESTIMONIOS_FO] ERROR: Token CSRF inválido');
            return [
                'success' => false,
                'error' => $this->l('Token de seguridad inválido. Por favor, recarga la página e inténtalo de nuevo.')
            ];
        }

        error_log('[GESTOR_TESTIMONIOS_FO] Token CSRF válido, continuando...');

        // Recoger datos del formulario
        $client_name = trim(Tools::getValue('client_name'));
        $company = trim(Tools::getValue('company'));
        $email = trim(Tools::getValue('email'));
        $testimonial_text = trim(Tools::getValue('testimonial_text'));
        $rating = (int)Tools::getValue('rating');
        $privacy_accept = Tools::getValue('privacy_accept');

        error_log('[GESTOR_TESTIMONIOS_FO] Datos del formulario:');
        error_log('[GESTOR_TESTIMONIOS_FO] - client_name: ' . $client_name);
        error_log('[GESTOR_TESTIMONIOS_FO] - company: ' . $company);
        error_log('[GESTOR_TESTIMONIOS_FO] - email: ' . $email);
        error_log('[GESTOR_TESTIMONIOS_FO] - testimonial_text length: ' . strlen($testimonial_text));
        error_log('[GESTOR_TESTIMONIOS_FO] - rating: ' . $rating);
        error_log('[GESTOR_TESTIMONIOS_FO] - privacy_accept: ' . ($privacy_accept ? 'YES' : 'NO'));

        // Validaciones básicas
        if (empty($client_name)) {
            error_log('[GESTOR_TESTIMONIOS_FO] ERROR: Nombre del cliente vacío');
            return [
                'success' => false,
                'error' => $this->l('El nombre del cliente es obligatorio.')
            ];
        }

        if (empty($testimonial_text)) {
            error_log('[GESTOR_TESTIMONIOS_FO] ERROR: Texto del testimonio vacío');
            return [
                'success' => false,
                'error' => $this->l('El texto del testimonio es obligatorio.')
            ];
        }

        if (!$privacy_accept) {
            error_log('[GESTOR_TESTIMONIOS_FO] ERROR: Términos de privacidad no aceptados');
            return [
                'success' => false,
                'error' => $this->l('Debes aceptar los términos de privacidad para enviar tu testimonio.')
            ];
        }

        if (strlen($testimonial_text) < 10) {
            return [
                'success' => false,
                'error' => $this->l('El testimonio debe tener al menos 10 caracteres.')
            ];
        }

        if (strlen($testimonial_text) > 2000) {
            return [
                'success' => false,
                'error' => $this->l('El testimonio no puede superar los 2000 caracteres.')
            ];
        }

        // Validar email si se proporciona
        if (!empty($email) && !Validate::isEmail($email)) {
            return [
                'success' => false,
                'error' => $this->l('El formato del email no es válido.')
            ];
        }

        // Validar rating si se proporciona
        $min_rating = Configuration::get('GESTOR_TESTIMONIOS_MIN_RATING');
        $max_rating = Configuration::get('GESTOR_TESTIMONIOS_MAX_RATING');

        if ($rating > 0 && ($rating < $min_rating || $rating > $max_rating)) {
            return [
                'success' => false,
                'error' => sprintf(
                    $this->l('La valoración debe estar entre %d y %d.'),
                    $min_rating,
                    $max_rating
                )
            ];
        }

        // Verificar si el cliente está logueado
        $customer_id = null;
        if ($this->context->customer->isLogged()) {
            $customer_id = $this->context->customer->id;

            // Si está logueado y no proporcionó email, usar el del perfil
            if (empty($email)) {
                $email = $this->context->customer->email;
            }
        }

        // Preparar datos para guardar
        $testimonio_data = [
            'client_name' => $client_name,
            'company' => $company,
            'email' => $email,
            'testimonial_text' => $testimonial_text,
            'rating' => $rating > 0 ? $rating : null,
            'customer_id' => $customer_id
        ];

        error_log('[GESTOR_TESTIMONIOS_FO] Datos preparados para guardar: ' . print_r($testimonio_data, true));

        // Guardar testimonio
        error_log('[GESTOR_TESTIMONIOS_FO] Llamando a saveTestimonio...');
        $save_result = $this->module->saveTestimonio($testimonio_data);
        error_log('[GESTOR_TESTIMONIOS_FO] Resultado de saveTestimonio: ' . ($save_result ? 'TRUE' : 'FALSE'));

        if ($save_result) {
            // Limpiar formulario
            $_POST = [];

            $message = Configuration::get('GESTOR_TESTIMONIOS_AUTO_APPROVE')
                ? $this->l('¡Gracias! Tu testimonio ha sido publicado exitosamente.')
                : $this->l('¡Gracias! Tu testimonio ha sido enviado y será revisado antes de publicarse.');

            error_log('[GESTOR_TESTIMONIOS_FO] Testimonio guardado exitosamente. Mensaje: ' . $message);

            return [
                'success' => true,
                'message' => $message
            ];
        } else {
            error_log('[GESTOR_TESTIMONIOS_FO] ERROR: No se pudo guardar el testimonio');
            return [
                'success' => false,
                'error' => $this->l('Ha ocurrido un error al guardar el testimonio. Por favor, inténtalo de nuevo.')
            ];
        }
    }

    /**
     * Establecer metadatos de la página
     */
    public function setMedia() {
        parent::setMedia();

        // Título de la página
        $this->context->smarty->assign([
            'meta_title' => $this->l('Enviar Testimonio'),
            'meta_description' => $this->l('Comparte tu experiencia con nosotros. Envía tu testimonio y ayuda a otros clientes.'),
        ]);
    }

    /**
     * Breadcrumb personalizado
     */
    public function getBreadcrumbLinks() {
        $breadcrumb = parent::getBreadcrumbLinks();

        $breadcrumb['links'][] = [
            'title' => $this->l('Testimonios'),
            'url' => $this->context->link->getModuleLink('gestortestimonios', 'testimonios')
        ];

        $breadcrumb['links'][] = [
            'title' => $this->l('Enviar Testimonio'),
            'url' => $this->context->link->getModuleLink('gestortestimonios', 'enviar')
        ];

        return $breadcrumb;
    }

    /**
     * Procesar peticiones AJAX
     */
    public function displayAjax() {
        if (Tools::getValue('action') === 'validate_email') {
            $email = Tools::getValue('email');
            $valid = empty($email) || Validate::isEmail($email);

            die(json_encode(['valid' => $valid]));
        }
    }
}
