<?php

class GestortestimoniosEnviarModuleFrontController extends ModuleFrontController {

    public function initContent() {
        parent::initContent();

        error_log('[DEBUG] Controlador enviar.php ejecutándose');

        $success = false;
        $error = '';
        $message = '';

        // Procesar formulario si se envió
        if (Tools::isSubmit('submitTestimonio')) {
            error_log('[DEBUG] Formulario enviado, procesando...');

            // Recoger datos básicos
            $client_name = trim(Tools::getValue('client_name'));
            $testimonial_text = trim(Tools::getValue('testimonial_text'));
            $privacy_accept = Tools::getValue('privacy_accept');

            error_log('[DEBUG] Datos: name=' . $client_name . ', text_length=' . strlen($testimonial_text) . ', privacy=' . ($privacy_accept ? 'YES' : 'NO'));

            // Validaciones simples
            if (empty($client_name)) {
                $error = 'El nombre es obligatorio';
            } elseif (empty($testimonial_text)) {
                $error = 'El testimonio es obligatorio';
            } elseif (!$privacy_accept) {
                $error = 'Debes aceptar los términos de privacidad';
            } else {
                // Intentar guardar
                $testimonio_data = [
                    'client_name' => $client_name,
                    'company' => trim(Tools::getValue('company')),
                    'email' => trim(Tools::getValue('email')),
                    'testimonial_text' => $testimonial_text,
                    'rating' => (int)Tools::getValue('rating'),
                    'customer_id' => $this->context->customer->isLogged() ? $this->context->customer->id : null
                ];

                error_log('[DEBUG] Llamando a saveTestimonio...');
                if ($this->module->saveTestimonio($testimonio_data)) {
                    $success = true;
                    $message = '¡Gracias! Tu testimonio ha sido enviado correctamente.';
                    error_log('[DEBUG] Testimonio guardado con éxito');
                } else {
                    $error = 'Error al guardar el testimonio. Inténtalo de nuevo.';
                    error_log('[DEBUG] Error al guardar testimonio');
                }
            }
        }

        // Datos del formulario
        $form_data = [
            'client_name' => Tools::getValue('client_name', ''),
            'company' => Tools::getValue('company', ''),
            'email' => Tools::getValue('email', ''),
            'testimonial_text' => Tools::getValue('testimonial_text', ''),
            'rating' => Tools::getValue('rating', '')
        ];

        // Información del cliente logueado
        $customer_info = [];
        if ($this->context->customer->isLogged()) {
            $customer_info = [
                'firstname' => $this->context->customer->firstname,
                'lastname' => $this->context->customer->lastname,
                'email' => $this->context->customer->email,
                'id' => $this->context->customer->id
            ];
        }

        // Asignar variables a Smarty
        $this->context->smarty->assign([
            'form_data' => $form_data,
            'customer_info' => $customer_info,
            'success' => $success ? $message : false,
            'error' => $error,
            'min_rating' => 1,
            'max_rating' => 5,
            'csrf_token' => 'debug_token',
            'testimonios_link' => $this->context->link->getModuleLink('gestortestimonios', 'testimonios'),
            'module_dir' => $this->module->getPathUri()
        ]);

        error_log('[DEBUG] Variables asignadas a Smarty, estableciendo template...');
        $this->setTemplate('module:gestortestimonios/views/templates/front/enviar.tpl');
        error_log('[DEBUG] Template establecido');
    }
}
