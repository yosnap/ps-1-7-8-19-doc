<?php

class GestortestimoniosEnviar_simpleModuleFrontController extends ModuleFrontController {

    public function initContent() {
        parent::initContent();

        $success = false;
        $error = '';
        $message = '';

        // Procesar formulario si se envió
        if (Tools::isSubmit('submitTestimonio')) {
            $result = $this->processTestimonioForm();
            $success = $result['success'];
            $error = isset($result['error']) ? $result['error'] : '';
            $message = isset($result['message']) ? $result['message'] : '';
        }

        // Datos del formulario
        $form_data = [
            'client_name' => Tools::getValue('client_name', ''),
            'company' => Tools::getValue('company', ''),
            'email' => Tools::getValue('email', ''),
            'testimonial_text' => Tools::getValue('testimonial_text', ''),
            'rating' => Tools::getValue('rating', '')
        ];

        // Información del cliente logueado
        $customer_info = [];
        if ($this->context->customer->isLogged()) {
            $customer_info = [
                'firstname' => $this->context->customer->firstname,
                'lastname' => $this->context->customer->lastname,
                'email' => $this->context->customer->email,
                'id' => $this->context->customer->id
            ];
        }

        // Asignar variables a Smarty
        $this->context->smarty->assign([
            'form_data' => $form_data,
            'customer_info' => $customer_info,
            'success' => $success ? $message : false,
            'error' => $error,
            'min_rating' => 1,
            'max_rating' => 5,
            'csrf_token' => $this->module->generateCSRFToken(),
            'testimonios_link' => $this->context->link->getModuleLink('gestortestimonios', 'testimonios'),
            'module_dir' => $this->module->getPathUri()
        ]);

        // Establecer el template
        $this->setTemplate('module:gestortestimonios/views/templates/front/enviar.tpl');
    }

    private function processTestimonioForm() {
        // Validar token CSRF
        if (!$this->module->validateCSRFToken(Tools::getValue('csrf_token'))) {
            return [
                'success' => false,
                'error' => 'Token de seguridad inválido.'
            ];
        }

        // Recoger datos
        $client_name = trim(Tools::getValue('client_name'));
        $company = trim(Tools::getValue('company'));
        $email = trim(Tools::getValue('email'));
        $testimonial_text = trim(Tools::getValue('testimonial_text'));
        $rating = (int)Tools::getValue('rating');
        $privacy_accept = Tools::getValue('privacy_accept');

        // Validaciones básicas
        if (empty($client_name)) {
            return ['success' => false, 'error' => 'El nombre es obligatorio.'];
        }

        if (empty($testimonial_text)) {
            return ['success' => false, 'error' => 'El testimonio es obligatorio.'];
        }

        if (!$privacy_accept) {
            return ['success' => false, 'error' => 'Debes aceptar los términos de privacidad.'];
        }

        // Preparar datos
        $testimonio_data = [
            'client_name' => $client_name,
            'company' => $company,
            'email' => $email,
            'testimonial_text' => $testimonial_text,
            'rating' => $rating > 0 ? $rating : null,
            'customer_id' => $this->context->customer->isLogged() ? $this->context->customer->id : null
        ];

        // Guardar testimonio
        if ($this->module->saveTestimonio($testimonio_data)) {
            return [
                'success' => true,
                'message' => '¡Gracias! Tu testimonio ha sido enviado correctamente.'
            ];
        } else {
            return [
                'success' => false,
                'error' => 'Error al guardar el testimonio. Inténtalo de nuevo.'
            ];
        }
    }
}
