<?php

class GestortestimoniosEnviarModuleFrontController extends ModuleFrontController {

    public function initContent() {
        parent::initContent();

        error_log('[ENVIAR] Controlador enviar ejecutándose');

        // Si es POST, intentar guardar
        if ($_POST && isset($_POST['submitTestimonio'])) {
            error_log('[ENVIAR] POST detectado, guardando...');

            $data = [
                'client_name' => $_POST['client_name'] ?? 'Sin nombre',
                'testimonial_text' => $_POST['testimonial_text'] ?? 'Sin texto',
                'company' => $_POST['company'] ?? '',
                'email' => $_POST['email'] ?? '',
                'rating' => (int)($_POST['rating'] ?? 0),
                'customer_id' => null
            ];

            if ($this->module->saveTestimonio($data)) {
                error_log('[ENVIAR] Testimonio guardado exitosamente');
                echo '<h1>✅ Testimonio guardado correctamente!</h1>';
                echo '<a href="javascript:history.back()">Volver</a>';
                return;
            } else {
                error_log('[ENVIAR] Error al guardar testimonio');
                echo '<h1>❌ Error al guardar testimonio</h1>';
                echo '<a href="javascript:history.back()">Volver</a>';
                return;
            }
        }

        // Mostrar formulario simple
        echo '<h1>Formulario de Testimonio (Versión Simple)</h1>';
        echo '<form method="post" style="max-width: 500px; margin: 20px;">';
        echo '<div style="margin: 10px 0;">';
        echo '<label>Nombre:</label><br>';
        echo '<input type="text" name="client_name" required style="width: 100%; padding: 5px;">';
        echo '</div>';
        echo '<div style="margin: 10px 0;">';
        echo '<label>Email:</label><br>';
        echo '<input type="email" name="email" style="width: 100%; padding: 5px;">';
        echo '</div>';
        echo '<div style="margin: 10px 0;">';
        echo '<label>Testimonio:</label><br>';
        echo '<textarea name="testimonial_text" required style="width: 100%; padding: 5px; height: 100px;"></textarea>';
        echo '</div>';
        echo '<div style="margin: 10px 0;">';
        echo '<label>Rating (1-5):</label><br>';
        echo '<select name="rating" style="padding: 5px;">';
        echo '<option value="">Sin rating</option>';
        for ($i = 1; $i <= 5; $i++) {
            echo '<option value="' . $i . '">' . $i . ' estrella' . ($i > 1 ? 's' : '') . '</option>';
        }
        echo '</select>';
        echo '</div>';
        echo '<div style="margin: 10px 0;">';
        echo '<input type="checkbox" name="privacy_accept" required> Acepto términos de privacidad';
        echo '</div>';
        echo '<button type="submit" name="submitTestimonio" style="background: #007cba; color: white; padding: 10px 20px; border: none;">Enviar Testimonio</button>';
        echo '</form>';

        error_log('[ENVIAR] Formulario mostrado');
    }
}
