<?php

/**
 * Controlador de prueba simple para testimonios
 * Archivo: controllers/front/test.php
 */

class GestortestimoniosTestModuleFrontController extends ModuleFrontController {
    public function initContent() {
        parent::initContent();

        error_log('[TEST] Controlador test del módulo funcionando');

        die('TEST: Controlador frontend funciona!');
    }
}
