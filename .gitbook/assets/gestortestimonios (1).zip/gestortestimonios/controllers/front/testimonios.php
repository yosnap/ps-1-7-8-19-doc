<?php

/**
 * Controlador Frontend para mostrar testimonios
 * Archivo: controllers/front/testimonios.php
 */

class GestortestimoniosTestimoniosModuleFrontController extends ModuleFrontController {
    public function __construct() {
        parent::__construct();
        $this->context = Context::getContext();
    }

    /**
     * Inicializar el controlador
     */
    public function init() {
        parent::init();

        // Verificar si el módulo está habilitado (opcional para debug)
        // if (!Configuration::get('GESTOR_TESTIMONIOS_ENABLED')) {
        //     Tools::redirect('index');
        // }
    }

    /**
     * Procesar la petición
     */
    public function initContent() {
        parent::initContent();

        // Parámetros de paginación
        $page = (int)Tools::getValue('page', 1);
        $per_page = (int)Configuration::get('GESTOR_TESTIMONIOS_MAX_PER_PAGE') ?: 10;
        $offset = ($page - 1) * $per_page;

        // Obtener testimonios aprobados
        $testimonios = $this->getTestimonios($per_page, $offset);
        $total_testimonios = $this->getTotalTestimonios();
        $total_pages = ceil($total_testimonios / $per_page);

        // Estadísticas
        $estadisticas = $this->module->getTestimoniosStats();

        // Asignar variables a Smarty
        $this->context->smarty->assign([
            'testimonios' => $testimonios,
            'current_page' => $page,
            'total_pages' => $total_pages,
            'total_testimonios' => $total_testimonios,
            'per_page' => $per_page,
            'estadisticas' => $estadisticas,
            'enviar_testimonio_link' => $this->context->link->getModuleLink(
                'gestortestimonios',
                'enviar'
            ),
            'module_dir' => $this->module->getPathUri(),
            'pagination_links' => $this->generatePaginationLinks($page, $total_pages)
        ]);

        // Establecer el template
        $this->setTemplate('module:gestortestimonios/views/templates/front/testimonios.tpl');
    }

    /**
     * Obtener testimonios paginados
     */
    private function getTestimonios($limit, $offset) {
        $sql = 'SELECT t.*, c.firstname, c.lastname
                FROM `' . _DB_PREFIX_ . 'testimonios` t
                LEFT JOIN `' . _DB_PREFIX_ . 'customer` c ON t.customer_id = c.id_customer
                WHERE t.status = "approved"
                ORDER BY t.created_at DESC
                LIMIT ' . (int)$offset . ', ' . (int)$limit;

        return Db::getInstance()->executeS($sql);
    }

    /**
     * Obtener total de testimonios aprobados
     */
    private function getTotalTestimonios() {
        $sql = 'SELECT COUNT(*) as total
                FROM `' . _DB_PREFIX_ . 'testimonios`
                WHERE status = "approved"';

        $result = Db::getInstance()->getRow($sql);
        return (int)$result['total'];
    }

    /**
     * Generar enlaces de paginación
     */
    private function generatePaginationLinks($current_page, $total_pages) {
        $links = [];
        $base_url = $this->context->link->getModuleLink('gestortestimonios', 'testimonios');

        // Primera página
        if ($current_page > 1) {
            $links['first'] = $base_url;
            $links['prev'] = $base_url . '?page=' . ($current_page - 1);
        }

        // Páginas alrededor de la actual
        $start = max(1, $current_page - 2);
        $end = min($total_pages, $current_page + 2);

        for ($i = $start; $i <= $end; $i++) {
            $links['pages'][$i] = [
                'url' => $base_url . '?page=' . $i,
                'current' => ($i == $current_page)
            ];
        }

        // Última página
        if ($current_page < $total_pages) {
            $links['next'] = $base_url . '?page=' . ($current_page + 1);
            $links['last'] = $base_url . '?page=' . $total_pages;
        }

        return $links;
    }

    /**
     * Establecer metadatos de la página
     */
    public function setMedia() {
        parent::setMedia();

        // Título de la página
        $this->context->smarty->assign([
            'meta_title' => $this->l('Testimonios de Clientes'),
            'meta_description' => $this->l('Lee lo que nuestros clientes dicen sobre nosotros. Testimonios reales de clientes satisfechos.'),
        ]);
    }

    /**
     * Breadcrumb personalizado
     */
    public function getBreadcrumbLinks() {
        $breadcrumb = parent::getBreadcrumbLinks();

        $breadcrumb['links'][] = [
            'title' => $this->l('Testimonios'),
            'url' => $this->context->link->getModuleLink('gestortestimonios', 'testimonios')
        ];

        return $breadcrumb;
    }
}
