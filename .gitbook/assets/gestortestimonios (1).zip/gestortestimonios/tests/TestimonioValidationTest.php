<?php

/**
 * Test unitario para el módulo Gestor de Testimonios
 *
 * @author Tu Nombre
 * @copyright 2024
 */

require_once __DIR__ . '/../gestortestimonios.php';

/**
 * Clase de test para validación de testimonios
 */
class TestimonioValidationTest {
    private $module;

    public function __construct() {
        // Simular contexto de PrestaShop para testing
        $this->module = new GestorTestimonios();
    }

    /**
     * Test de validación de datos válidos
     */
    public function testValidateTestimonyValid() {
        $validData = [
            'customer_name' => 'Juan Pérez',
            'customer_email' => 'juan@example.com',
            'id_product' => 1,
            'rating' => 5,
            'testimony' => 'Excelente producto, muy recomendado para todos.'
        ];

        $result = $this->module->validateTestimony($validData);

        $this->assertTrue($result['valid'], 'Datos válidos deberían pasar la validación');
        $this->assertEmpty($result['errors'], 'No debería haber errores con datos válidos');
    }

    /**
     * Test de validación con nombre vacío
     */
    public function testValidateTestimonyEmptyName() {
        $invalidData = [
            'customer_name' => '',
            'customer_email' => 'juan@example.com',
            'id_product' => 1,
            'rating' => 5,
            'testimony' => 'Buen producto'
        ];

        $result = $this->module->validateTestimony($invalidData);

        $this->assertFalse($result['valid'], 'Nombre vacío debería fallar la validación');
        $this->assertContains('El nombre es obligatorio', $result['errors']);
    }

    /**
     * Test de validación con email inválido
     */
    public function testValidateTestimonyInvalidEmail() {
        $invalidData = [
            'customer_name' => 'Juan Pérez',
            'customer_email' => 'email-invalido',
            'id_product' => 1,
            'rating' => 5,
            'testimony' => 'Buen producto'
        ];

        $result = $this->module->validateTestimony($invalidData);

        $this->assertFalse($result['valid'], 'Email inválido debería fallar la validación');
        $this->assertContains('El email no es válido', $result['errors']);
    }

    /**
     * Test de validación con calificación fuera de rango
     */
    public function testValidateTestimonyInvalidRating() {
        $invalidData = [
            'customer_name' => 'Juan Pérez',
            'customer_email' => 'juan@example.com',
            'id_product' => 1,
            'rating' => 6, // Fuera del rango 1-5
            'testimony' => 'Buen producto'
        ];

        $result = $this->module->validateTestimony($invalidData);

        $this->assertFalse($result['valid'], 'Calificación fuera de rango debería fallar');
        $this->assertContains('La calificación debe ser entre 1 y 5', $result['errors']);
    }

    /**
     * Test de validación con testimonio muy corto
     */
    public function testValidateTestimonyTooShort() {
        $invalidData = [
            'customer_name' => 'Juan Pérez',
            'customer_email' => 'juan@example.com',
            'id_product' => 1,
            'rating' => 5,
            'testimony' => 'Bien' // Muy corto (menos de 10 caracteres)
        ];

        $result = $this->module->validateTestimony($invalidData);

        $this->assertFalse($result['valid'], 'Testimonio muy corto debería fallar');
        $this->assertContains('El testimonio debe tener al menos 10 caracteres', $result['errors']);
    }

    /**
     * Test de validación con testimonio muy largo
     */
    public function testValidateTestimonyTooLong() {
        $invalidData = [
            'customer_name' => 'Juan Pérez',
            'customer_email' => 'juan@example.com',
            'id_product' => 1,
            'rating' => 5,
            'testimony' => str_repeat('a', 1001) // Más de 1000 caracteres
        ];

        $result = $this->module->validateTestimony($invalidData);

        $this->assertFalse($result['valid'], 'Testimonio muy largo debería fallar');
        $this->assertContains('El testimonio no puede exceder 1000 caracteres', $result['errors']);
    }

    /**
     * Método de aserción personalizado
     */
    private function assertTrue($condition, $message = '') {
        if (!$condition) {
            throw new Exception("FAIL: $message");
        }
        echo "PASS: $message\n";
    }

    /**
     * Método de aserción personalizado
     */
    private function assertFalse($condition, $message = '') {
        if ($condition) {
            throw new Exception("FAIL: $message");
        }
        echo "PASS: $message\n";
    }

    /**
     * Método de aserción personalizado
     */
    private function assertEmpty($array, $message = '') {
        if (!empty($array)) {
            throw new Exception("FAIL: $message");
        }
        echo "PASS: $message\n";
    }

    /**
     * Método de aserción personalizado
     */
    private function assertContains($needle, $haystack, $message = '') {
        if (!in_array($needle, $haystack)) {
            throw new Exception("FAIL: $message - '$needle' not found in array");
        }
        echo "PASS: $message\n";
    }

    /**
     * Ejecutar todos los tests
     */
    public function runAllTests() {
        echo "=== EJECUTANDO TESTS DE VALIDACIÓN ===\n\n";

        try {
            $this->testValidateTestimonyValid();
            $this->testValidateTestimonyEmptyName();
            $this->testValidateTestimonyInvalidEmail();
            $this->testValidateTestimonyInvalidRating();
            $this->testValidateTestimonyTooShort();
            $this->testValidateTestimonyTooLong();

            echo "\n=== TODOS LOS TESTS PASARON ===\n";
        } catch (Exception $e) {
            echo "\n=== ERROR EN TEST ===\n";
            echo $e->getMessage() . "\n";
        }
    }
}

// Ejecutar tests solo si se ejecuta directamente
if (basename(__FILE__) == basename($_SERVER['SCRIPT_NAME'])) {
    $test = new TestimonioValidationTest();
    $test->runAllTests();
}
