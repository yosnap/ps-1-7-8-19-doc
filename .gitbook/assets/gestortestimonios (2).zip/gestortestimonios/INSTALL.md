# Instalación y Configuración del Módulo Gestor de Testimonios

## Prerrequisitos

- PrestaShop 1.7.8.x
- PHP 7.2 o superior
- MySQL 5.6 o superior
- Acceso al panel de administración de PrestaShop

## 1. Instalación del Módulo

### Paso 1: Copiar archivos

```bash
# ⚠️ IMPORTANTE: Copiar a modules/ NO a custom-modules/
# Desde el directorio raíz de PrestaShop
cp -r custom-modules/gestortestimonios modules/
```

### Paso 2: Verificar permisos

```bash
# Asegurar permisos correctos
chmod -R 755 modules/gestortestimonios/
chmod -R 644 modules/gestortestimonios/*.php
chmod -R 644 modules/gestortestimonios/views/
```

### Paso 3: Instalar desde el Back-Office

1. Ir a **Módulos → Module Manager**
2. Buscar "Gestor de Testimonios"
3. Hacer clic en **"Instalar"**
4. Confirmar la instalación

### Paso 4: Limpiar caché (CRÍTICO para evitar 404)

1. Ir a **Parámetros avanzados → Rendimiento**
2. Hacer clic en **"Limpiar caché"**
3. O manualmente: `rm -rf var/cache/*`

## 2. Configuración Inicial

### Paso 1: Configurar el módulo

1. Ir a **Módulos → Module Manager**
2. Buscar "Gestor de Testimonios" en módulos instalados
3. Hacer clic en **"Configurar"**
4. Ajustar las siguientes opciones:
   - **Módulo habilitado**: Sí
   - **Aprobación automática**: No (recomendado)
   - **Testimonios por página**: 10
   - **Calificación mínima**: 1
   - **Calificación máxima**: 5

### Paso 2: Verificar Hooks

El módulo se registra automáticamente en los siguientes hooks:

- `displayHeader` - Carga CSS y JS
- `displayHome` - Muestra testimonios en página principal
- `displayFooter` - Enlaces de navegación
- `displayCustomerAccount` - Enlaces en cuenta del cliente
- `displayAdminOrderLeft` - Información adicional en pedidos

### Paso 3: Verificar Base de Datos

La tabla `ps_testimonios` debería haberse creado automáticamente con la siguiente estructura:

```sql
SHOW TABLES LIKE 'ps_testimonios';
DESCRIBE ps_testimonios;
```

## 3. Verificación de Funcionamiento

### Frontend

- **Página principal**: Debería mostrar sección de testimonios (si hay testimonios aprobados)
- **Footer**: Debería mostrar enlaces "Ver testimonios" y "Enviar testimonio"
- **URL de testimonios**: `tu-tienda.com/module/gestortestimonios/testimonios`
- **URL de envío**: `tu-tienda.com/module/gestortestimonios/enviar`

### Backend

- **Panel de configuración**: Accesible desde Module Manager
- **Estadísticas**: Total, pendientes, aprobados, rechazados
- **Gestión**: Aprobar, rechazar, eliminar testimonios

## 4. Configuración Opcional

### CSS Personalizado

Para personalizar estilos, editar:

```
modules/gestortestimonios/views/css/gestortestimonios.css
```

### JavaScript Personalizado

Para personalizar comportamiento:

```
modules/gestortestimonios/views/js/gestortestimonios.js
```

### Traducciones

Para añadir idiomas:

```
modules/gestortestimonios/translations/[idioma].php
```

## 5. Testing

### Test Básico de Funcionalidad

1. **Enviar testimonio**:

   - Ir a `tu-tienda.com/module/gestortestimonios/enviar`
   - Llenar formulario con datos válidos
   - Verificar mensaje de éxito

2. **Administrar testimonio**:

   - Ir al panel de administración del módulo
   - Verificar que aparece en "Pendientes"
   - Aprobar o rechazar el testimonio

3. **Ver testimonios**:
   - Ir a `tu-tienda.com/module/gestortestimonios/testimonios`
   - Verificar que aparecen testimonios aprobados
   - Probar paginación

### Test de Validación

```bash
# Ejecutar tests unitarios (opcional)
cd modules/gestortestimonios/
php tests/TestimonioValidationTest.php
```

## 6. Troubleshooting

### Problemas Comunes

**El módulo no aparece en Module Manager**

- Verificar que la carpeta está en `modules/gestortestimonios/`
- Verificar permisos de archivos
- Limpiar caché de PrestaShop

**Error 500 al instalar**

- Verificar logs de Apache: `logs/apache2/error.log`
- Verificar sintaxis PHP de archivos del módulo
- Verificar permisos de base de datos

**CSS/JS no se carga**

- Verificar que el archivo esté en `views/css/` o `views/js/`
- Limpiar caché de PrestaShop
- Verificar hook `displayHeader`

**Formulario no envía datos**

- Verificar token CSRF en formulario
- Verificar permisos de escritura en base de datos
- Revisar logs de errores PHP

### Logs de Debug

```bash
# Habilitar debug en PrestaShop
# config/defines.inc.php
define('_PS_MODE_DEV_', true);

# Ver logs
tail -f logs/apache2/error.log
tail -f var/logs/dev.log
```

## 7. Mantenimiento

### Copias de Seguridad

```sql
-- Backup de testimonios
mysqldump -u usuario -p nombre_bd ps_testimonios > testimonios_backup.sql
```

### Actualizaciones

1. Hacer backup de la base de datos
2. Hacer backup de archivos personalizados
3. Reemplazar archivos del módulo
4. Ejecutar upgrade si es necesario

### Limpieza

```sql
-- Eliminar testimonios antiguos (opcional)
DELETE FROM ps_testimonios WHERE date_add < DATE_SUB(NOW(), INTERVAL 2 YEAR);

-- Eliminar testimonios rechazados
DELETE FROM ps_testimonios WHERE status = 'rejected';
```

## 8. Soporte

### Información de Debug

Para reportar errores, incluir:

- Versión de PrestaShop
- Versión de PHP
- Versión de MySQL
- Configuración del módulo
- Logs de error relevantes
- Pasos para reproducir el problema

### Recursos

- **Documentación**: `README.md`
- **Tests**: `tests/TestimonioValidationTest.php`
- **Configuración**: Panel de administración del módulo
- **Logs**: `logs/apache2/error.log` y `var/logs/`
