# Gestor de Testimonios - PrestaShop Module

## Descripción

El módulo **Gestor de Testimonios** permite a los clientes de tu tienda PrestaShop enviar testimonios sobre los productos que han comprado. Los administradores pueden revisar, aprobar, rechazar y gestionar estos testimonios desde el panel administrativo.

## Características principales

### 🔧 **Funcionalidades para Administradores**

- Panel de configuración completo en el back-office
- Sistema de aprobación/rechazo de testimonios
- Estadísticas en tiempo real (total, pendientes, aprobados, rechazados)
- Gestión de testimonios pendientes y recientes
- Configuración del número de testimonios a mostrar
- Eliminación de testimonios no deseados

### 👥 **Funcionalidades para Clientes**

- Formulario de envío de testimonios con validación
- Sistema de calificación por estrellas (1-5)
- Selección de productos comprados
- Página dedicada para ver todos los testimonios
- Display de testimonios en la página principal
- Enlaces en el footer para acceso rápido

### 🛡️ **Seguridad y Validación**

- Protección CSRF en todos los formularios
- Validación completa de campos (nombre, email, calificación, testimonio)
- Sanitización de datos de entrada
- Control de longitud de testimonios (10-1000 caracteres)
- Archivos de seguridad `index.php` en todos los directorios

### 🎨 **Diseño y UX**

- Interfaz responsive para todos los dispositivos
- Sistema de calificación visual con estrellas
- Animaciones CSS suaves
- Contador de caracteres en tiempo real
- Validación JavaScript del lado cliente
- Alertas y mensajes informativos

## Estructura del módulo

```
gestortestimonios/
├── gestortestimonios.php          # Archivo principal del módulo
├── controllers/
│   └── front/
│       ├── testimonios.php        # Controlador para listar testimonios
│       └── enviar.php             # Controlador para enviar testimonios
├── views/
│   ├── css/
│   │   └── gestortestimonios.css  # Estilos principales
│   ├── js/
│   │   └── gestortestimonios.js   # JavaScript para validación y UX
│   └── templates/
│       ├── admin/
│       │   └── configure.tpl      # Panel de configuración admin
│       ├── hook/
│       │   ├── testimonios-home.tpl  # Testimonios en página principal
│       │   └── testimonios-footer.tpl # Enlaces en footer
│       └── front/
│           ├── testimonios.tpl    # Página de listado de testimonios
│           └── enviar.tpl         # Formulario de envío
├── translations/
│   └── es.php                     # Traducciones en español
└── README.md                      # Esta documentación
```

## Instalación

1. **Copiar el módulo**: Coloca la carpeta `gestortestimonios` en el directorio `modules/` de tu instalación de PrestaShop.

2. **Instalar desde el back-office**:

   - Ve a Módulos → Module Manager
   - Busca "Gestor de Testimonios"
   - Haz clic en "Instalar"

3. **Configurar el módulo**:
   - Ve a Módulos → Module Manager
   - Busca "Gestor de Testimonios" y haz clic en "Configurar"
   - Ajusta las opciones según tus necesidades

## Base de datos

El módulo crea automáticamente la tabla `{prefix}_testimonios` con la siguiente estructura:

```sql
CREATE TABLE `{prefix}_testimonios` (
  `id_testimonio` int(11) NOT NULL AUTO_INCREMENT,
  `id_product` int(11) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `customer_email` varchar(255) NOT NULL,
  `rating` tinyint(1) NOT NULL,
  `testimony` text NOT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `date_add` datetime NOT NULL,
  `date_upd` datetime NOT NULL,
  PRIMARY KEY (`id_testimonio`),
  KEY `idx_product` (`id_product`),
  KEY `idx_status` (`status`)
);
```

## Hooks utilizados

- **displayHeader**: Incluye CSS y JS en todas las páginas
- **displayHome**: Muestra testimonios destacados en la página principal
- **displayFooter**: Añade enlaces de navegación en el footer
- **displayCustomerAccount**: Enlaces en la cuenta del cliente
- **displayAdminOrderLeft**: Información adicional en pedidos (admin)

## Configuraciones disponibles

- **GESTORTESTIMONIOS_HOME_COUNT**: Número de testimonios a mostrar en la página principal (por defecto: 3)

## URLs del frontend

- **Listado de testimonios**: `{tu-tienda}/module/gestortestimonios/testimonios`
- **Enviar testimonio**: `{tu-tienda}/module/gestortestimonios/enviar`

## Personalización

### CSS

Los estilos se encuentran en `views/css/gestortestimonios.css`. Puedes personalizarlos según el diseño de tu tema.

### JavaScript

La validación y efectos interactivos están en `views/js/gestortestimonios.js`.

### Plantillas

Todas las plantillas usan Smarty y se pueden personalizar:

- **Admin**: `views/templates/admin/configure.tpl`
- **Frontend**: `views/templates/front/`
- **Hooks**: `views/templates/hook/`

## Traducciones

Las traducciones se gestionan en el archivo `translations/es.php`. Para añadir nuevos idiomas:

1. Crea un nuevo archivo como `translations/en.php`
2. Traduce todas las claves manteniendo la estructura
3. Limpia la caché de PrestaShop

## Desarrollo y testing

### Tests unitarios (recomendado)

```bash
# Instalar PHPUnit
composer require --dev phpunit/phpunit

# Crear tests para validación
mkdir tests/
# Crear archivos de test para métodos críticos como validateTestimony(), CRUD operations, etc.
```

### Debugging

- Logs de Apache: `logs/apache2/error.log`
- Logs de PHP: Configurar `log_errors` en PHP
- Xdebug: Configurado en `conf/php/xdebug.ini`

## Compatibilidad

- **PrestaShop**: 1.7.8.x
- **PHP**: 7.2+
- **MySQL**: 5.6+
- **Navegadores**: Chrome, Firefox, Safari, Edge (versiones modernas)

## Contribución

1. Haz fork del proyecto
2. Crea una rama para tu feature (`git checkout -b feature/nueva-funcionalidad`)
3. Commit tus cambios (`git commit -am 'Añadir nueva funcionalidad'`)
4. Push a la rama (`git push origin feature/nueva-funcionalidad`)
5. Crea un Pull Request

## Licencia

Este módulo está licenciado bajo la Academic Free License (AFL 3.0), la misma licencia que PrestaShop.

## Soporte

Para reportar bugs o solicitar nuevas funcionalidades, por favor:

1. Revisa la documentación
2. Verifica los logs de error
3. Crea un issue detallado con pasos para reproducir el problema

## Changelog

### v1.0.0 (Actual)

- ✅ Implementación inicial completa
- ✅ Sistema CRUD de testimonios
- ✅ Panel de administración
- ✅ Frontend responsive
- ✅ Validación y seguridad
- ✅ Hooks de PrestaShop
- ✅ Traducciones en español

### Próximas versiones

- 📋 Sistema de notificaciones por email
- 📋 API REST para testimonios
- 📋 Integración con redes sociales
- 📋 Importación/exportación de testimonios
- 📋 Sistema de moderación automática
- 📋 Widget para sidebar
- 📋 Schema.org markup para SEO
