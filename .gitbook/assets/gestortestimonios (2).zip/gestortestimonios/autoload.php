<?php

/**
 * Autoloader para el módulo GestorTestimonios
 * Asegura que las clases del módulo se carguen correctamente
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

// Registrar el autoloader para el controlador admin
spl_autoload_register(function ($class) {
    // Solo cargar clases relacionadas con este módulo
    if (strpos($class, 'AdminGestorTestimonios') === 0) {
        $file = dirname(__FILE__) . '/controllers/admin/' . $class . '.php';
        if (file_exists($file)) {
            require_once $file;
            return true;
        }
    }
    return false;
});

// Asegurar que las clases base están disponibles
if (!class_exists('ModuleAdminController')) {
    if (file_exists(_PS_ROOT_DIR_ . '/classes/controller/ModuleAdminController.php')) {
        require_once _PS_ROOT_DIR_ . '/classes/controller/ModuleAdminController.php';
    }
}
