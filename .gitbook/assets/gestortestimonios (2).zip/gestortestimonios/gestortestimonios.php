<?php

/**
 * Módulo Gestor de Testimonios de Clientes para PrestaShop 1.7.8.x
 * Basado en las especificaciones del proyecto final
 * Plan de Formación PrestaShop
 *
 * @author Plan de Formación PrestaShop
 * @version 1.0.0
 * @license AFL 3.0
 * @copyright 2024
 *
 * Este módulo permite gestionar testimonios de clientes con:
 * - Sistema de aprobación/rechazo
 * - Panel de administración completo
 * - Validación y seguridad CSRF
 * - Rating por estrellas
 * - Frontend responsive
 * - Hooks múltiples de PrestaShop
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Clase principal del módulo Gestor de Testimonios
 *
 * @extends Module
 */
class GestorTestimonios extends Module {
    public function __construct() {
        $this->name = 'gestortestimonios';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'Desarrollo PS';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = [
            'min' => '1.7.0.0',
            'max' => _PS_VERSION_
        ];
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Gestor de Testimonios de Clientes');
        $this->description = $this->l('Módulo profesional para gestionar testimonios de clientes con sistema de aprobación, rating y panel de administración completo.');

        $this->confirmUninstall = $this->l('¿Estás seguro de que quieres desinstalar este módulo? Se perderán todos los testimonios almacenados.');
    }

    /**
     * Instalación del módulo
     */
    public function install() {
        $install_result = parent::install();

        if (!$install_result) {
            return false;
        }

        // Registrar hooks necesarios
        $hooks = [
            'displayHeader',           // Para cargar CSS/JS
            'displayHome',            // Mostrar testimonios en home
            'displayFooter',          // Mostrar testimonios en footer
            'displayCustomerAccount', // Enlace en cuenta cliente
            'displayAdminOrderLeft'   // Panel admin en pedidos
        ];

        foreach ($hooks as $hook) {
            if (!$this->registerHook($hook)) {
                return false;
            }
        }

        // Crear tabla de testimonios
        if (!$this->createTestimoniosTable()) {
            return false;
        }

        // Registrar rutas personalizadas
        if (!$this->installRoutes()) {
            return false;
        }

        // Configuración inicial
        Configuration::updateValue('GESTOR_TESTIMONIOS_ENABLED', 1);
        Configuration::updateValue('GESTOR_TESTIMONIOS_AUTO_APPROVE', 0);
        Configuration::updateValue('GESTOR_TESTIMONIOS_MAX_PER_PAGE', 5);
        Configuration::updateValue('GESTOR_TESTIMONIOS_MIN_RATING', 1);
        Configuration::updateValue('GESTOR_TESTIMONIOS_MAX_RATING', 5);

        return true;
    }

    /**
     * Desinstalación del módulo
     */
    public function uninstall() {
        // Eliminar tabla de testimonios
        $this->dropTestimoniosTable();

        // Eliminar configuraciones
        Configuration::deleteByName('GESTOR_TESTIMONIOS_ENABLED');
        Configuration::deleteByName('GESTOR_TESTIMONIOS_AUTO_APPROVE');
        Configuration::deleteByName('GESTOR_TESTIMONIOS_MAX_PER_PAGE');
        Configuration::deleteByName('GESTOR_TESTIMONIOS_MIN_RATING');
        Configuration::deleteByName('GESTOR_TESTIMONIOS_MAX_RATING');

        return parent::uninstall();
    }

    /**
     * Crear tabla de testimonios según especificaciones
     */
    private function createTestimoniosTable() {
        $sql = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'testimonios` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `client_name` varchar(255) NOT NULL,
            `company` varchar(255) NULL,
            `testimonial_text` text NOT NULL,
            `rating` tinyint(1) UNSIGNED NULL,
            `status` enum("pending", "approved", "rejected") NOT NULL DEFAULT "pending",
            `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
            `customer_id` int(11) NULL,
            `email` varchar(255) NULL,
            `display_order` int(11) DEFAULT 0,
            PRIMARY KEY (`id`),
            KEY `idx_status` (`status`),
            KEY `idx_created` (`created_at`),
            KEY `idx_rating` (`rating`),
            CONSTRAINT `chk_rating` CHECK (`rating` IS NULL OR (`rating` >= 1 AND `rating` <= 5))
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

        $result = Db::getInstance()->execute($sql);

        if (!$result) {
            $error = Db::getInstance()->getMsgError();
            PrestaShopLogger::addLog(
                'GestorTestimonios: Error creating table - ' . $error,
                3,
                null,
                'GestorTestimonios'
            );
        }

        return $result;
    }

    /**
     * Eliminar tabla de testimonios
     */
    private function dropTestimoniosTable() {
        $sql = 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'testimonios`';
        return Db::getInstance()->execute($sql);
    }

    /**
     * Hook: displayHeader
     * Cargar CSS y JS necesarios
     */
    public function hookDisplayHeader() {
        // Solo cargar en páginas relevantes
        $controller = $this->context->controller;
        $page_name = get_class($controller);

        if (
            $page_name === 'IndexController' ||
            $page_name === 'TestimoniosController' ||
            $this->isTestimoniosPage()
        ) {

            $this->context->controller->addCSS($this->_path . 'views/css/gestortestimonios.css');
            $this->context->controller->addJS($this->_path . 'views/js/gestortestimonios.js');
        }
    }

    /**
     * Hook: displayHome
     * Mostrar testimonios aprobados en la página de inicio
     */
    public function hookDisplayHome() {
        if (!Configuration::get('GESTOR_TESTIMONIOS_ENABLED')) {
            return '';
        }

        $testimonios = $this->getApprovedTestimonios(
            Configuration::get('GESTOR_TESTIMONIOS_MAX_PER_PAGE')
        );

        if (empty($testimonios)) {
            return '';
        }

        $this->context->smarty->assign([
            'testimonios' => $testimonios,
            'show_rating' => true,
            'module_dir' => $this->_path
        ]);

        return $this->display(__FILE__, 'views/templates/hook/testimonios-home.tpl');
    }

    /**
     * Hook: displayFooter
     * Mostrar enlace para enviar testimonio
     */
    public function hookDisplayFooter() {
        if (!Configuration::get('GESTOR_TESTIMONIOS_ENABLED')) {
            return '';
        }

        $this->context->smarty->assign([
            'testimonios_link' => $this->context->link->getModuleLink(
                'gestortestimonios',
                'testimonios'
            ),
            'enviar_testimonio_link' => $this->context->link->getModuleLink(
                'gestortestimonios',
                'enviar'
            )
        ]);

        return $this->display(__FILE__, 'views/templates/hook/testimonios-footer.tpl');
    }

    /**
     * Página de configuración del módulo
     */
    public function getContent() {
        $output = '';


        // Procesar formulario de configuración
        if (Tools::isSubmit('submit' . $this->name)) {
            $output .= $this->processConfiguration();
        }

        // Procesar acciones de testimonios
        if (Tools::isSubmit('approveTestimonio')) {
            $id = Tools::getValue('id_testimonio');
            $output .= $this->approveTestimonio($id);
        }

        if (Tools::isSubmit('rejectTestimonio')) {
            $id = Tools::getValue('id_testimonio');
            $output .= $this->rejectTestimonio($id);
        }

        if (Tools::isSubmit('deleteTestimonio')) {
            $id = Tools::getValue('id_testimonio');
            $output .= $this->deleteTestimonio($id);
        }

        return $output . $this->displayConfigurationForm();
    }

    /**
     * Procesar configuración del módulo
     */
    private function processConfiguration() {
        $enabled = Tools::getValue('GESTOR_TESTIMONIOS_ENABLED');
        $auto_approve = Tools::getValue('GESTOR_TESTIMONIOS_AUTO_APPROVE');
        $max_per_page = (int)Tools::getValue('GESTOR_TESTIMONIOS_MAX_PER_PAGE');
        $min_rating = (int)Tools::getValue('GESTOR_TESTIMONIOS_MIN_RATING');
        $max_rating = (int)Tools::getValue('GESTOR_TESTIMONIOS_MAX_RATING');

        // Validaciones
        if ($max_per_page < 1 || $max_per_page > 50) {
            return $this->displayError($this->l('El número de testimonios por página debe estar entre 1 y 50.'));
        }

        if ($min_rating < 1 || $min_rating > 5 || $max_rating < 1 || $max_rating > 5 || $min_rating >= $max_rating) {
            return $this->displayError($this->l('Las valoraciones deben estar entre 1 y 5, y el mínimo debe ser menor que el máximo.'));
        }

        // Guardar configuración
        Configuration::updateValue('GESTOR_TESTIMONIOS_ENABLED', $enabled);
        Configuration::updateValue('GESTOR_TESTIMONIOS_AUTO_APPROVE', $auto_approve);
        Configuration::updateValue('GESTOR_TESTIMONIOS_MAX_PER_PAGE', $max_per_page);
        Configuration::updateValue('GESTOR_TESTIMONIOS_MIN_RATING', $min_rating);
        Configuration::updateValue('GESTOR_TESTIMONIOS_MAX_RATING', $max_rating);

        return $this->displayConfirmation($this->l('Configuración guardada exitosamente.'));
    }

    /**
     * Mostrar formulario de configuración
     */
    private function displayConfigurationForm() {
        // Obtener testimonios pendientes y recientes
        $testimonios_pendientes = $this->getPendingTestimonios();
        $testimonios_recientes = $this->getRecentTestimonios(10);
        $estadisticas = $this->getTestimoniosStats();
        $store_url = $this->context->shop->getBaseURL(true);


        $this->context->smarty->assign([
            'module_dir' => $this->_path,
            'gestor_enabled' => Configuration::get('GESTOR_TESTIMONIOS_ENABLED'),
            'auto_approve' => Configuration::get('GESTOR_TESTIMONIOS_AUTO_APPROVE'),
            'max_per_page' => Configuration::get('GESTOR_TESTIMONIOS_MAX_PER_PAGE'),
            'min_rating' => Configuration::get('GESTOR_TESTIMONIOS_MIN_RATING'),
            'max_rating' => Configuration::get('GESTOR_TESTIMONIOS_MAX_RATING'),
            'testimonios_pendientes' => $testimonios_pendientes,
            'testimonios_recientes' => $testimonios_recientes,
            'estadisticas' => $estadisticas,
            'submit_action' => 'submit' . $this->name,
            'store_url' => $store_url
        ]);

        return $this->display(__FILE__, 'views/templates/admin/configure.tpl');
    }

    /**
     * Obtener testimonios aprobados
     */
    public function getApprovedTestimonios($limit = 10, $random = false) {
        $orderBy = $random ? 'RAND()' : 't.created_at DESC';

        $sql = 'SELECT t.*, c.firstname, c.lastname
                FROM `' . _DB_PREFIX_ . 'testimonios` t
                LEFT JOIN `' . _DB_PREFIX_ . 'customer` c ON t.customer_id = c.id_customer
                WHERE t.status = "approved"
                ORDER BY ' . $orderBy . '
                LIMIT ' . (int)$limit;

        return Db::getInstance()->executeS($sql);
    }

    /**
     * Obtener testimonios pendientes de aprobación
     */
    public function getPendingTestimonios() {
        $sql = 'SELECT t.*, c.firstname, c.lastname
                FROM `' . _DB_PREFIX_ . 'testimonios` t
                LEFT JOIN `' . _DB_PREFIX_ . 'customer` c ON t.customer_id = c.id_customer
                WHERE t.status = "pending"
                ORDER BY t.created_at DESC';

        return Db::getInstance()->executeS($sql);
    }

    /**
     * Obtener testimonios recientes
     */
    public function getRecentTestimonios($limit = 10) {
        $sql = 'SELECT t.*, c.firstname, c.lastname
                FROM `' . _DB_PREFIX_ . 'testimonios` t
                LEFT JOIN `' . _DB_PREFIX_ . 'customer` c ON t.customer_id = c.id_customer
                ORDER BY t.created_at DESC
                LIMIT ' . (int)$limit;

        return Db::getInstance()->executeS($sql);
    }

    /**
     * Obtener estadísticas de testimonios
     */
    public function getTestimoniosStats() {
        $sql = 'SELECT
                    COUNT(*) as total,
                    SUM(CASE WHEN status = "approved" THEN 1 ELSE 0 END) as approved,
                    SUM(CASE WHEN status = "pending" THEN 1 ELSE 0 END) as pending,
                    SUM(CASE WHEN status = "rejected" THEN 1 ELSE 0 END) as rejected,
                    AVG(rating) as avg_rating
                FROM `' . _DB_PREFIX_ . 'testimonios`';

        $result = Db::getInstance()->getRow($sql);

        return [
            'total' => (int)$result['total'],
            'approved' => (int)$result['approved'],
            'pending' => (int)$result['pending'],
            'rejected' => (int)$result['rejected'],
            'avg_rating' => round((float)$result['avg_rating'], 2)
        ];
    }

    /**
     * Aprobar testimonio
     */
    public function approveTestimonio($id) {
        $id = (int)$id;
        if ($id <= 0) {
            return $this->displayError($this->l('ID de testimonio inválido.'));
        }

        $sql = 'UPDATE `' . _DB_PREFIX_ . 'testimonios`
                SET status = "approved"
                WHERE id = ' . $id;

        if (Db::getInstance()->execute($sql)) {
            return $this->displayConfirmation($this->l('Testimonio aprobado exitosamente.'));
        } else {
            return $this->displayError($this->l('Error al aprobar el testimonio.'));
        }
    }

    /**
     * Rechazar testimonio
     */
    public function rejectTestimonio($id) {
        $id = (int)$id;
        if ($id <= 0) {
            return $this->displayError($this->l('ID de testimonio inválido.'));
        }

        $sql = 'UPDATE `' . _DB_PREFIX_ . 'testimonios`
                SET status = "rejected"
                WHERE id = ' . $id;

        if (Db::getInstance()->execute($sql)) {
            return $this->displayConfirmation($this->l('Testimonio rechazado exitosamente.'));
        } else {
            return $this->displayError($this->l('Error al rechazar el testimonio.'));
        }
    }

    /**
     * Eliminar testimonio
     */
    public function deleteTestimonio($id) {
        $id = (int)$id;
        if ($id <= 0) {
            return $this->displayError($this->l('ID de testimonio inválido.'));
        }

        $sql = 'DELETE FROM `' . _DB_PREFIX_ . 'testimonios` WHERE id = ' . $id;

        if (Db::getInstance()->execute($sql)) {
            return $this->displayConfirmation($this->l('Testimonio eliminado exitosamente.'));
        } else {
            return $this->displayError($this->l('Error al eliminar el testimonio.'));
        }
    }

    /**
     * Guardar nuevo testimonio
     */
    public function saveTestimonio($data) {
        // Validación de datos
        if (empty($data['client_name']) || empty($data['testimonial_text'])) {
            return false;
        }

        // Sanear datos de entrada
        $client_name = pSQL($data['client_name']);
        $company = !empty($data['company']) ? pSQL($data['company']) : null;
        $testimonial_text = pSQL($data['testimonial_text']);
        $rating = !empty($data['rating']) ? (int)$data['rating'] : null;
        $email = !empty($data['email']) ? pSQL($data['email']) : null;
        $customer_id = !empty($data['customer_id']) ? (int)$data['customer_id'] : null;

        // Estado inicial según configuración
        $status = Configuration::get('GESTOR_TESTIMONIOS_AUTO_APPROVE') ? 'approved' : 'pending';

        $sql = 'INSERT INTO `' . _DB_PREFIX_ . 'testimonios`
                (client_name, company, testimonial_text, rating, status, email, customer_id, created_at)
                VALUES ("' . $client_name . '", ' .
            ($company ? '"' . $company . '"' : 'NULL') . ', "' .
            $testimonial_text . '", ' .
            ($rating ? $rating : 'NULL') . ', "' .
            $status . '", ' .
            ($email ? '"' . $email . '"' : 'NULL') . ', ' .
            ($customer_id ? $customer_id : 'NULL') . ', NOW())';

        $result = Db::getInstance()->execute($sql);

        if (!$result) {
            $error = Db::getInstance()->getMsgError();
            PrestaShopLogger::addLog(
                'GestorTestimonios: Error saving testimonial - ' . $error,
                3,
                null,
                'GestorTestimonios'
            );
        }

        return $result;
    }

    /**
     * Verificar si estamos en página de testimonios
     */
    private function isTestimoniosPage() {
        return Tools::getValue('controller') === 'testimonios' ||
            Tools::getValue('controller') === 'enviar';
    }

    /**
     * Generar token CSRF usando sistema de PrestaShop
     */
    public function generateCSRFToken() {
        // Usar el sistema de tokens de PrestaShop
        return Tools::getToken(false);
    }

    /**
     * Validar token CSRF usando sistema de PrestaShop
     */
    public function validateCSRFToken($token) {
        // Usar el sistema de validación de PrestaShop
        return Tools::getToken(false) === $token;
    }

    /**
     * Instalar rutas personalizadas
     */
    public function installRoutes() {
        try {
            // No es necesario registrar rutas manualmente en PrestaShop 1.7
            // Los controladores se detectan automáticamente si están en la carpeta correcta
            return true;
        } catch (Exception $e) {
            PrestaShopLogger::addLog(
                'Error instalando rutas del módulo: ' . $e->getMessage(),
                3,
                null,
                'GestorTestimonios',
                $this->id
            );
            return false;
        }
    }
}
