<?php

global $_MODULE;
$_MODULE = array();

// Módulo principal
$_MODULE['<{gestortestimonios}prestashop>gestortestimonios_3c6e0b8a9c15224a8228b9a98ca1531d'] = 'Gestor de Testimonios';
$_MODULE['<{gestortestimonios}prestashop>gestortestimonios_f2a6c498fb90ee345d997f888fce3b18'] = 'Permite a los clientes enviar testimonios y gestionarlos desde el panel administrativo';
$_MODULE['<{gestortestimonios}prestashop>gestortestimonios_c888438d14855d7d96a2724ee9c306bd'] = 'Configuración guardada';
$_MODULE['<{gestortestimonios}prestashop>gestortestimonios_630f6dc397fe74e52d5189e2c80f282b'] = 'Volver a la lista';
$_MODULE['<{gestortestimonios}prestashop>gestortestimonios_f4f70727dc34561dfde1a3c529b6205c'] = 'Configuración';

// Configuración admin
$_MODULE['<{gestortestimonios}prestashop>configure_cf6329da10e027be90d26306cc88bff6'] = 'Configuración del Gestor de Testimonios';
$_MODULE['<{gestortestimonios}prestashop>configure_1f87346a16cf80c372065de3c54c86d9'] = 'Número de testimonios a mostrar en la página principal';
$_MODULE['<{gestortestimonios}prestashop>configure_b5a7adde1af5c87d7fd797b6245c2a39'] = 'Descripción';
$_MODULE['<{gestortestimonios}prestashop>configure_630f6dc397fe74e52d5189e2c80f282b'] = 'Volver a la lista';
$_MODULE['<{gestortestimonios}prestashop>configure_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{gestortestimonios}prestashop>configure_86024cad1e83101d97359d7351051156'] = 'Estadísticas';
$_MODULE['<{gestortestimonios}prestashop>configure_d027ad9e3b25526641b2e2e0bb6e6271'] = 'Total de testimonios';
$_MODULE['<{gestortestimonios}prestashop>configure_b9f5c797ebbf55adccdd8539a65a0241'] = 'Pendientes';
$_MODULE['<{gestortestimonios}prestashop>configure_8f0fa0157bad2268e21c40e01da68ebe'] = 'Aprobados';
$_MODULE['<{gestortestimonios}prestashop>configure_b68b8e61f119648c8e2e0de6c31acc3e'] = 'Rechazados';
$_MODULE['<{gestortestimonios}prestashop>configure_39816631e37c8d0ec49b5e37ee3c4d59'] = 'Testimonios pendientes de aprobación';
$_MODULE['<{gestortestimonios}prestashop>configure_67daf92c833c41c95db874e18fcb2786'] = 'Nombre';
$_MODULE['<{gestortestimonios}prestashop>configure_baec6461b0d69dfc8cee0a3c532e0b9b'] = 'Producto';
$_MODULE['<{gestortestimonios}prestashop>configure_240c8c70bf9f8e16937b99b24004da40'] = 'Calificación';
$_MODULE['<{gestortestimonios}prestashop>configure_a9d5d6e4ad35d55b5fd66bcec6b8b12e'] = 'Testimonio';
$_MODULE['<{gestortestimonios}prestashop>configure_52f5e0bc3859bc5f5e25130b6c7e8881'] = 'Fecha';
$_MODULE['<{gestortestimonios}prestashop>configure_004bf6c9a40003140292e97330236c53'] = 'Acciones';
$_MODULE['<{gestortestimonios}prestashop>configure_67be0c95b6c8c1c5e3f8f9bd8c16b8d7'] = 'Aprobar';
$_MODULE['<{gestortestimonios}prestashop>configure_2fac2bbd5fb8c6de1ad0b8b1b1d3c9ad'] = 'Rechazar';
$_MODULE['<{gestortestimonios}prestashop>configure_f2a6c498fb90ee345d997f888fce3b18'] = 'Eliminar';
$_MODULE['<{gestortestimonios}prestashop>configure_5b4b8ad0fb5ca9b6b3d69d843b2dfc2b'] = 'Testimonios recientes';
$_MODULE['<{gestortestimonios}prestashop>configure_e6ce7b14b8eb5bb3b3e5c6a2f8ea1e77'] = 'Sin testimonios pendientes';
$_MODULE['<{gestortestimonios}prestashop>configure_5e7c6b52c5b8e1c7a3f0e7e3e8d5b8a2'] = 'Sin testimonios recientes';

// Frontend - testimonios
$_MODULE['<{gestortestimonios}prestashop>testimonios_3c6e0b8a9c15224a8228b9a98ca1531d'] = 'Testimonios';
$_MODULE['<{gestortestimonios}prestashop>testimonios_d4f3d56f4c3b4e1e4f7e3c4b4e1d3f4e'] = 'Testimonios de nuestros clientes';
$_MODULE['<{gestortestimonios}prestashop>testimonios_1e3b7b8b8b8c5c3c3f8f8f8f8f8f8f8'] = 'Ver más testimonios';
$_MODULE['<{gestortestimonios}prestashop>testimonios_3e7e2e0c3c3c3c3c3c3c3c3c3c3c3c3c'] = '¿Quieres compartir tu experiencia?';
$_MODULE['<{gestortestimonios}prestashop>testimonios_f2a6c498fb90ee345d997f888fce3b18'] = 'Enviar testimonio';
$_MODULE['<{gestortestimonios}prestashop>testimonios_e6ce7b14b8eb5bb3b3e5c6a2f8ea1e77'] = 'No hay testimonios disponibles';
$_MODULE['<{gestortestimonios}prestashop>testimonios_5b8e3b4b4b4b4b4b4b4b4b4b4b4b4b4'] = 'Página anterior';
$_MODULE['<{gestortestimonios}prestashop>testimonios_4b4e4b4b4b4b4b4b4b4b4b4b4b4b4b4b'] = 'Página siguiente';

// Frontend - enviar
$_MODULE['<{gestortestimonios}prestashop>enviar_f2a6c498fb90ee345d997f888fce3b18'] = 'Enviar testimonio';
$_MODULE['<{gestortestimonios}prestashop>enviar_5b5e3b4b4b4b4b4b4b4b4b4b4b4b4b4b'] = 'Comparte tu experiencia con otros clientes';
$_MODULE['<{gestortestimonios}prestashop>enviar_67daf92c833c41c95db874e18fcb2786'] = 'Nombre';
$_MODULE['<{gestortestimonios}prestashop>enviar_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'Email';
$_MODULE['<{gestortestimonios}prestashop>enviar_baec6461b0d69dfc8cee0a3c532e0b9b'] = 'Producto';
$_MODULE['<{gestortestimonios}prestashop>enviar_5b8b5c3c3c3c3c3c3c3c3c3c3c3c3c3c'] = 'Seleccionar producto...';
$_MODULE['<{gestortestimonios}prestashop>enviar_240c8c70bf9f8e16937b99b24004da40'] = 'Calificación';
$_MODULE['<{gestortestimonios}prestashop>enviar_a9d5d6e4ad35d55b5fd66bcec6b8b12e'] = 'Testimonio';
$_MODULE['<{gestortestimonios}prestashop>enviar_5e7c6b52c5b8e1c7a3f0e7e3e8d5b8a2'] = 'Cuenta tu experiencia con el producto...';
$_MODULE['<{gestortestimonios}prestashop>enviar_f2a6c498fb90ee345d997f888fce3b18'] = 'Enviar';
$_MODULE['<{gestortestimonios}prestashop>enviar_5b8e4b4b4b4b4b4b4b4b4b4b4b4b4b4b'] = 'Todos los campos son obligatorios';
$_MODULE['<{gestortestimonios}prestashop>enviar_5e7e4b4b4b4b4b4b4b4b4b4b4b4b4b4b'] = 'Tu testimonio será revisado antes de ser publicado';
$_MODULE['<{gestortestimonios}prestashop>enviar_3b4e4b4b4b4b4b4b4b4b4b4b4b4b4b4b'] = 'Respetamos tu privacidad. Tu email no será publicado';

// Mensajes de error y éxito
$_MODULE['<{gestortestimonios}prestashop>success_3b8e4b4b4b4b4b4b4b4b4b4b4b4b4b4b'] = '¡Gracias por tu testimonio! Será revisado y publicado pronto.';
$_MODULE['<{gestortestimonios}prestashop>error_5b4e4b4b4b4b4b4b4b4b4b4b4b4b4b4b'] = 'Error al procesar tu testimonio. Inténtalo de nuevo.';
$_MODULE['<{gestortestimonios}prestashop>error_name_required'] = 'El nombre es obligatorio';
$_MODULE['<{gestortestimonios}prestashop>error_email_required'] = 'El email es obligatorio';
$_MODULE['<{gestortestimonios}prestashop>error_email_invalid'] = 'El email no es válido';
$_MODULE['<{gestortestimonios}prestashop>error_product_required'] = 'Debes seleccionar un producto';
$_MODULE['<{gestortestimonios}prestashop>error_rating_required'] = 'La calificación es obligatoria';
$_MODULE['<{gestortestimonios}prestashop>error_rating_invalid'] = 'La calificación debe ser entre 1 y 5';
$_MODULE['<{gestortestimonios}prestashop>error_testimony_required'] = 'El testimonio es obligatorio';
$_MODULE['<{gestortestimonios}prestashop>error_testimony_too_short'] = 'El testimonio debe tener al menos 10 caracteres';
$_MODULE['<{gestortestimonios}prestashop>error_testimony_too_long'] = 'El testimonio no puede exceder 1000 caracteres';
$_MODULE['<{gestortestimonios}prestashop>error_csrf'] = 'Token de seguridad inválido';
