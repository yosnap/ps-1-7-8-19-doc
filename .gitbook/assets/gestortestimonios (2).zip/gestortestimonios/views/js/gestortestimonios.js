/**
 * JavaScript para el módulo Gestor de Testimonios
 * Archivo: views/js/gestortestimonios.js
 */

document.addEventListener('DOMContentLoaded', function() {
    'use strict';

    console.log('Gestor de Testimonios JS cargado');

    // === CONFIGURACIÓN GLOBAL ===
    const CONFIG = {
        charLimit: 2000,
        charWarning: 1800,
        emailValidationDelay: 500,
        animationDuration: 300
    };

    // === ELEMENTOS DEL DOM ===
    const elements = {
        form: document.getElementById('testimonioForm'),
        testimonialText: document.getElementById('testimonial_text'),
        charCounter: document.querySelector('.char-counter'),
        emailInput: document.getElementById('email'),
        ratingInputs: document.querySelectorAll('input[name="rating"]'),
        ratingDescription: document.querySelector('.rating-description'),
        submitButton: document.querySelector('button[name="submitTestimonio"]'),
        privacyCheckbox: document.getElementById('privacy_accept')
    };

    // === MENSAJES DE RATING ===
    const ratingMessages = {
        1: 'Muy insatisfecho - Nos ayudará a mejorar',
        2: 'Insatisfecho - Valoramos tu opinión',
        3: 'Neutral - Gracias por tu honestidad',
        4: 'Satisfecho - ¡Nos alegra saberlo!',
        5: 'Muy satisfecho - ¡Excelente experiencia!'
    };

    // === FUNCIONES PRINCIPALES ===

    // Inicializar rating con estrellas
    function initStarRating() {
        if (!elements.ratingInputs.length) return;

        elements.ratingInputs.forEach(function(input, index) {
            input.addEventListener('change', function() {
                const rating = parseInt(this.value);
                updateRatingDisplay(rating);
                updateRatingDescription(rating);
            });
        });
    }

    // Actualizar visualización del rating
    function updateRatingDisplay(rating) {
        const stars = document.querySelectorAll('.rating-stars label');
        stars.forEach(function(star, index) {
            if (index < rating) {
                star.classList.add('selected');
            } else {
                star.classList.remove('selected');
            }
        });
    }

    // Actualizar descripción del rating
    function updateRatingDescription(rating) {
        if (elements.ratingDescription && ratingMessages[rating]) {
            elements.ratingDescription.textContent = ratingMessages[rating];
            elements.ratingDescription.style.display = 'block';
        }
    }

    // Inicializar contador de caracteres
    function initCharacterCounter() {
        if (!elements.testimonialText || !elements.charCounter) return;

        elements.testimonialText.addEventListener('input', function() {
            const currentLength = this.value.length;
            const remaining = CONFIG.charLimit - currentLength;

            elements.charCounter.textContent = remaining + ' caracteres restantes';

            if (remaining < 0) {
                elements.charCounter.classList.add('over-limit');
                elements.charCounter.classList.remove('warning');
            } else if (currentLength > CONFIG.charWarning) {
                elements.charCounter.classList.add('warning');
                elements.charCounter.classList.remove('over-limit');
            } else {
                elements.charCounter.classList.remove('warning', 'over-limit');
            }
        });

        // Trigger inicial
        elements.testimonialText.dispatchEvent(new Event('input'));
    }

    // Inicializar formulario de testimonio
    function initTestimonioForm() {
        if (!elements.form) return;

        elements.form.addEventListener('submit', function(e) {
            if (!validateForm()) {
                e.preventDefault();
                return false;
            }

            // Mostrar indicador de carga
            if (elements.submitButton) {
                elements.submitButton.disabled = true;
                elements.submitButton.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Enviando...';
            }
        });

        // Mejorar experiencia visual del formulario
        setupVisualEnhancements();
    }

    function setupVisualEnhancements() {
        var self = this;

        // Añadir contador de caracteres para textarea
        var mensaje = document.getElementById('mensaje');
        if (mensaje) {
            var counter = document.createElement('div');
            counter.className = 'character-counter';
            counter.setAttribute('data-max', '500');
            mensaje.parentNode.appendChild(counter);

            var updateCounter = function() {
                var length = mensaje.value.length;
                var max = 500;
                counter.textContent = length + '/' + max + ' caracteres';

                if (length > max * 0.8) {
                    counter.className = length > max ? 'character-counter error' : 'character-counter warning';
                } else {
                    counter.className = 'character-counter';
                }
            };

            mensaje.addEventListener('input', updateCounter);
            updateCounter();
        }

        // Añadir efectos de focus mejorados
        var inputs = document.querySelectorAll('.testimonios-form input, .testimonios-form textarea');
        inputs.forEach(function(input) {
            input.addEventListener('focus', function() {
                this.parentNode.classList.add('focused');
            });

            input.addEventListener('blur', function() {
                this.parentNode.classList.remove('focused');
            });
        });

        // Mejorar botón de envío con loading state
        var submitBtn = document.querySelector('.btn-primary[type="submit"]');
        if (submitBtn) {
            var form = submitBtn.closest('form');
            if (form) {
                form.addEventListener('submit', function() {
                    submitBtn.classList.add('loading');
                    submitBtn.textContent = 'Enviando...';
                });
            }
        }
    }

    // Validar formulario
    function validateForm() {
        let isValid = true;
        const errors = [];

        // Validar nombre del cliente
        const clientName = document.getElementById('client_name');
        if (clientName && !clientName.value.trim()) {
            errors.push('El nombre del cliente es obligatorio');
            isValid = false;
        }

        // Validar testimonio
        if (elements.testimonialText && !elements.testimonialText.value.trim()) {
            errors.push('El testimonio es obligatorio');
            isValid = false;
        }

        if (elements.testimonialText && elements.testimonialText.value.length > CONFIG.charLimit) {
            errors.push('El testimonio excede el límite de caracteres');
            isValid = false;
        }

        // Validar privacidad
        if (elements.privacyCheckbox && !elements.privacyCheckbox.checked) {
            errors.push('Debes aceptar los términos de privacidad');
            isValid = false;
        }

        // Validar email si se proporciona
        if (elements.emailInput && elements.emailInput.value.trim()) {
            if (!isValidEmail(elements.emailInput.value)) {
                errors.push('El formato del email no es válido');
                isValid = false;
            }
        }

        // Mostrar errores
        if (!isValid) {
            showFormErrors(errors);
        }

        return isValid;
    }

    // Validar email
    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    // Mostrar errores del formulario
    function showFormErrors(errors) {
        // Remover errores anteriores
        const existingErrors = document.querySelectorAll('.form-error-message');
        existingErrors.forEach(function(error) {
            error.remove();
        });

        // Crear contenedor de errores
        const errorContainer = document.createElement('div');
        errorContainer.className = 'alert alert-danger form-error-message';
        errorContainer.innerHTML = '<ul><li>' + errors.join('</li><li>') + '</li></ul>';

        // Insertar al inicio del formulario
        elements.form.insertBefore(errorContainer, elements.form.firstChild);

        // Scroll al error
        errorContainer.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }

    // === INICIALIZACIÓN ===

    // Inicializar todas las funcionalidades
    if (elements.form) {
        initTestimonioForm();
    }

    initStarRating();
    initCharacterCounter();

    console.log('Todas las funcionalidades del módulo inicializadas');
});
