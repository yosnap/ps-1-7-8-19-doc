<?php

/**
 * Controlador Frontend - Envío de Testimonios
 *
 * @extends ModuleFrontController
 */
class GestortestimoniosEnviarModuleFrontController extends ModuleFrontController {

    public function __construct() {
        parent::__construct();
        $this->context = Context::getContext();
    }

    /**
     * Inicializar el controlador
     */
    public function init() {
        parent::init();

        // Verificar si el módulo está habilitado
        if (!Configuration::get('GESTOR_TESTIMONIOS_ENABLED')) {
            Tools::redirect($this->context->link->getPageLink('index'));
        }
    }

    /**
     * Procesar la petición
     */
    public function initContent() {
        parent::initContent();


        $success = false;
        $error = '';
        $message = '';

        // Procesar formulario si se envió
        if (Tools::isSubmit('submitTestimonio')) {
            $result = $this->processTestimonioForm();
            $success = $result['success'];
            $error = isset($result['error']) ? $result['error'] : '';
            $message = isset($result['message']) ? $result['message'] : '';
        }

        // Datos del formulario (mantener datos si hay error)
        $form_data = [
            'client_name' => Tools::getValue('client_name', ''),
            'company' => Tools::getValue('company', ''),
            'email' => Tools::getValue('email', ''),
            'testimonial_text' => Tools::getValue('testimonial_text', ''),
            'rating' => Tools::getValue('rating', '')
        ];

        // Información del cliente logueado
        $customer_info = [];
        if ($this->context->customer->isLogged()) {
            $customer_info = [
                'firstname' => $this->context->customer->firstname,
                'lastname' => $this->context->customer->lastname,
                'email' => $this->context->customer->email,
                'id' => $this->context->customer->id
            ];
        }

        // Configuración de rating
        $min_rating = Configuration::get('GESTOR_TESTIMONIOS_MIN_RATING');
        $max_rating = Configuration::get('GESTOR_TESTIMONIOS_MAX_RATING');

        // Asignar variables a Smarty
        $this->context->smarty->assign([
            'form_data' => $form_data,
            'customer_info' => $customer_info,
            'success' => $success ? $message : false,
            'error' => $error,
            'min_rating' => $min_rating,
            'max_rating' => $max_rating,
            'csrf_token' => $this->module->generateCSRFToken(),
            'testimonios_link' => $this->context->link->getModuleLink(
                'gestortestimonios',
                'testimonios'
            ),
            'module_dir' => $this->module->getPathUri()
        ]);

        // USAR TEMPLATE FINAL SIN CSS PROBLEMÁTICO
        $this->setTemplate('module:gestortestimonios/views/templates/front/enviar.tpl');
    }

    /**
     * Procesar formulario de testimonio
     */
    private function processTestimonioForm() {

        // CSRF DESACTIVADO TEMPORALMENTE PARA DIAGNOSTICAR
        // Validar token CSRF
        $csrf_token = Tools::getValue('csrf_token');

        // COMENTADO TEMPORALMENTE PARA QUE FUNCIONE
        /*
        if (!$this->module->validateCSRFToken($csrf_token)) {
            error_log('[GESTOR_TESTIMONIOS_FO] ERROR: Token CSRF inválido');
            return [
                'success' => false,
                'error' => $this->l('Token de seguridad inválido. Por favor, recarga la página e inténtalo de nuevo.')
            ];
        }
        */


        // Recoger datos del formulario
        $client_name = trim(Tools::getValue('client_name'));
        $company = trim(Tools::getValue('company'));
        $email = trim(Tools::getValue('email'));
        $testimonial_text = trim(Tools::getValue('testimonial_text'));
        $rating = (int)Tools::getValue('rating');
        $privacy_accept = Tools::getValue('privacy_accept');


        // Validaciones básicas
        if (empty($client_name)) {
            return [
                'success' => false,
                'error' => $this->l('El nombre del cliente es obligatorio.')
            ];
        }

        if (empty($testimonial_text)) {
            return [
                'success' => false,
                'error' => $this->l('El texto del testimonio es obligatorio.')
            ];
        }

        if (!$privacy_accept) {
            return [
                'success' => false,
                'error' => $this->l('Debes aceptar los términos de privacidad para enviar tu testimonio.')
            ];
        }

        if (strlen($testimonial_text) < 10) {
            return [
                'success' => false,
                'error' => $this->l('El testimonio debe tener al menos 10 caracteres.')
            ];
        }

        if (strlen($testimonial_text) > 2000) {
            return [
                'success' => false,
                'error' => $this->l('El testimonio no puede superar los 2000 caracteres.')
            ];
        }

        // Validar email si se proporciona
        if (!empty($email) && !Validate::isEmail($email)) {
            return [
                'success' => false,
                'error' => $this->l('El formato del email no es válido.')
            ];
        }

        // Validar rating si se proporciona
        $min_rating = Configuration::get('GESTOR_TESTIMONIOS_MIN_RATING');
        $max_rating = Configuration::get('GESTOR_TESTIMONIOS_MAX_RATING');

        if ($rating > 0 && ($rating < $min_rating || $rating > $max_rating)) {
            return [
                'success' => false,
                'error' => sprintf(
                    $this->l('La valoración debe estar entre %d y %d.'),
                    $min_rating,
                    $max_rating
                )
            ];
        }

        // Verificar si el cliente está logueado
        $customer_id = null;
        if ($this->context->customer->isLogged()) {
            $customer_id = $this->context->customer->id;

            // Si está logueado y no proporcionó email, usar el del perfil
            if (empty($email)) {
                $email = $this->context->customer->email;
            }
        }

        // Preparar datos para guardar
        $testimonio_data = [
            'client_name' => $client_name,
            'company' => $company,
            'email' => $email,
            'testimonial_text' => $testimonial_text,
            'rating' => $rating > 0 ? $rating : null,
            'customer_id' => $customer_id
        ];


        // Guardar testimonio
        $save_result = $this->module->saveTestimonio($testimonio_data);

        if ($save_result) {
            // Limpiar formulario
            $_POST = [];

            $message = Configuration::get('GESTOR_TESTIMONIOS_AUTO_APPROVE')
                ? $this->l('¡Gracias! Tu testimonio ha sido publicado exitosamente.')
                : $this->l('¡Gracias! Tu testimonio ha sido enviado y será revisado antes de publicarse.');


            return [
                'success' => true,
                'message' => $message
            ];
        } else {
            return [
                'success' => false,
                'error' => $this->l('Ha ocurrido un error al guardar el testimonio. Por favor, inténtalo de nuevo.')
            ];
        }
    }

    /**
     * Establecer metadatos de la página
     */
    public function setMedia() {
        parent::setMedia();

        // Título de la página
        $this->context->smarty->assign([
            'meta_title' => $this->l('Enviar Testimonio'),
            'meta_description' => $this->l('Comparte tu experiencia con nosotros. Envía tu testimonio y ayuda a otros clientes.'),
        ]);
    }

    public function getBreadcrumbLinks() {
        $breadcrumb = parent::getBreadcrumbLinks();

        $breadcrumb['links'][] = [
            'title' => $this->trans('Testimonios de Clientes', [], 'Modules.Gestortestimonios.Front'),
            'url' => $this->context->link->getModuleLink('gestortestimonios', 'testimonios')
        ];

        $breadcrumb['links'][] = [
            'title' => $this->trans('Enviar Testimonio', [], 'Modules.Gestortestimonios.Front'),
            'url' => $this->context->link->getModuleLink('gestortestimonios', 'enviar')
        ];

        return $breadcrumb;
    }

    /**
     * Procesar peticiones AJAX
     */
    public function displayAjax() {
        if (Tools::getValue('action') === 'validate_email') {
            $email = Tools::getValue('email');
            $valid = empty($email) || Validate::isEmail($email);

            die(json_encode(['valid' => $valid]));
        }
    }
}
