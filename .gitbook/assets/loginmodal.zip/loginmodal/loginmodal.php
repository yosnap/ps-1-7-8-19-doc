<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

class LoginModal extends Module {
    public function __construct() {
        $this->name = 'loginmodal';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'Desarrollo PS';
        $this->need_instance = 1;
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Modal para mostrar descuentos');
        $this->description = $this->l('Módulo para mostrar descuentos al iniciar sesión por primera vez');
        $this->ps_versions_compliancy = ['min' => '1.7', 'max' => _PS_VERSION_];
    }

    /**
     * Instalación del módulo
     */
    public function install() {
        return parent::install() &&
            $this->registerHook('actionAuthentication') && // Detectar login
            $this->registerHook('displayHome') &&          // Mostrar mensaje
            $this->registerHook('displayHeader');        // Cargar CS
        //$this->registerHook('displayFooter');             //Cargar JS - de momento no lo usamos
    }

    /**
     * Desinstalación del módulo
     */
    public function uninstall() {
        return parent::uninstall();
    }

    /**
     * HOOK DE ACCIÓN: Usamos la Cookie de sesión de PS
     * Su única responsabilidad es levantar una 'bandera' en la sesión.
     */
    public function hookActionAuthentication($params) {
        // El nombre de la cookie es descriptivo.
        $this->context->cookie->showDiscountMessage = 1;
    }

    /**
     * HOOK DE DISPLAY: Carga nuestro CSS. De momento no necesitamos JS.
     */
    public function hookDisplayHeader($params) {
        if ($this->context->controller->php_self == 'index') {
            $this->context->controller->registerStylesheet(
                'discount-css',
                $this->_path . 'views/css/discount.css',
                ['media' => 'all', 'priority' => 150]
            );
        }
    }

    /**
     * HOOK DE DISPLAY: Se ejecuta en el cuerpo de la página de inicio.
     * Comprueba la 'bandera' y, si está levantada, muestra el banner y baja la bandera.
     */
    public function hookDisplayHome($params) {
        // Comprobamos si nuestra bandera existe y está activa
        if (isset($this->context->cookie->showDiscountMessage) && $this->context->cookie->showDiscountMessage) {

            // Inmediatamente 'bajamos la bandera' para que no se vuelva a mostrar
            unset($this->context->cookie->showDiscountMessage);

            // Renderizamos y devolvemos la plantilla del banner
            return $this->display(__FILE__, 'views/templates/hook/discount_banner.tpl');
        }
    }
}
