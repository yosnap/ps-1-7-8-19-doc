document.addEventListener('DOMContentLoaded', function () {
    const overlay = document.getElementById('login-modal-overlay');
    const closeModalButton = document.getElementById('login-modal-close');

    // Si el modal no está en pantalla, no hacemos nada más
    if (!overlay) {
        return;
    }

    // Cerramos el modal
    function closeModal() {
        overlay.style.display = 'none';
    }

    // Eventos para cerrar el modal

    closeModalButton.addEventListener('click', closeModal);
    overlay.addEventListener('click', function (event) {
        if (event.target === overlay) {
            closeModal()
        }
    });
});
